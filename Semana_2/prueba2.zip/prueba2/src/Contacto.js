import React, { Component } from "react";

class Contacto extends Component{

	render(){
		return(
			<div>
				<h2>Contacto</h2>
			</div>
		);
	}

}

export default Contacto;