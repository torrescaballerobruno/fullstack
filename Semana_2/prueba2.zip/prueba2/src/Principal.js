import React, { Component } from "react";

class Principal extends Component{

	render(){
		return(
			<div>
				<h2>Hola!</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus reprehenderit qui eaque totam quae nesciunt atque maxime aspernatur, perferendis commodi ducimus iusto blanditiis tempore autem est pariatur facere doloribus. Qui.</p>

				<p>Aqui iria toda mi informacion</p>
			</div>
		);
	}

}

export default Principal;